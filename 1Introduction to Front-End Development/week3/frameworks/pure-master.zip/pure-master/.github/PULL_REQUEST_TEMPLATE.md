Please consider the following before submitting a pull request:

Guidelines for contributing: https://github.com/pure-css/pure/blob/master/CONTRIBUTING.md

Example of changes on an interactive website such as the following:

- http://jsbin.com/
- http://jsfiddle.net/
- http://codepen.io/pen/

---

<!-- The following statement must stay in the PR description -->

I confirm that this contribution is made under a BSD license and that I have the authority necessary to make this contribution on behalf of its copyright owner.
